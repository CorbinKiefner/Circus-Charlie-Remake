This project requires the Microsoft XNA Framework in order to run properly. 
If you do not have it installed on your machine, the project will not run correctly.

This project was made to better understand how 3D models can be manipulated directly using raw code.