﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using System;
using System.Collections.Generic;

namespace CircusCharlie3D
{
    public class circ : Game
    {
        //Initialize all necessary variables for the game
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        //models
        Model player;
        Model barrel;

        //textures
        Texture2D background;

        //mouse and keyboard control states
        MouseState mstate;
        KeyboardState kState;

        //Vectors
        Vector3 playerPos;
        Vector3 barrelInitPos;
        Vector3 cameraPos;
        List<Vector3> barrelPos;
        Vector2 startPosition = new Vector2(750, 750);

        //Fonts
        SpriteFont gameFont;
        SpriteFont largeGameFont;

        //Music
        Song menuMusic;
        Song playMusic;
        
        //Necessary number values
        float timer;
        float difficultyTimer;
        const float TARGET_RADIUS = 3.0f;
        
        //Game start and end states
        bool gameStart, gameOver;

        public circ()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {

            //player and barrel positions
            playerPos = new Vector3(0, -5, 0);
            cameraPos = new Vector3(playerPos.X, 10, 30);
            barrelPos = new List<Vector3>();
            barrelInitPos = new Vector3(playerPos.X + 20, playerPos.Y, playerPos.Z);

            //set the correct starting state for game elements
            timer = 0f;
            difficultyTimer = 15.0f;
            gameStart = false;
            gameOver = false;

            //initialize keyboard and mouse controls
            mstate = Mouse.GetState();
            kState = Keyboard.GetState();

            //change window size
            _graphics.PreferredBackBufferWidth = 1920;
            _graphics.PreferredBackBufferHeight = 1080;
            _graphics.IsFullScreen = true;
            _graphics.ApplyChanges();

            base.Initialize();
        }


        protected override void LoadContent()
        {
            //load the sprite batch, including all models and fonts
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            player = Content.Load<Model>("PlayerPlane");
            barrel = Content.Load<Model>("Barrel_Sealed_01");
            gameFont = Content.Load<SpriteFont>("Font");
            largeGameFont = Content.Load<SpriteFont>("LargeF");
            background = Content.Load<Texture2D>("background2");

            //Load music
            menuMusic = Content.Load<Song>("Monplaisir");
            playMusic = Content.Load<Song>("Sour Rock");

            //Play menu music
            MediaPlayer.Play(menuMusic);
            
        }

        protected override void Update(GameTime gameTime)
        {
            //If the player hits escape, close game
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            //Load mouse and keyboard states
            mstate = Mouse.GetState();
            kState = Keyboard.GetState();

            //If the user clicks the start button, set game to start and hide text
            if (mstate.LeftButton == ButtonState.Pressed && gameStart == false)
            {
                gameStart = true;
                MediaPlayer.Stop();
                MediaPlayer.Play(playMusic);
                startPosition = new Vector2(10000, 10000);
            }

            //If the game is currently running, run game code until player loses
            if (gameStart && !gameOver)
            {
                //Difficulty Increase 15 Seconds
                if(difficultyTimer <= 0f)
                {
                    if (Math.Floor(gameTime.TotalGameTime.TotalMilliseconds) % 1000 == 0)
                    {
                        barrelPos.Add(barrelInitPos);
                    }
                    for (int b = 0; b < barrelPos.Count; b++)
                    {
                        barrelPos[b] -= new Vector3(0.3f, 0, 0);
                    }
                }
                //Default Difficulty
                else
                {
                    if (Math.Floor(gameTime.TotalGameTime.TotalMilliseconds) % 2000 == 0)
                    {
                        barrelPos.Add(barrelInitPos);
                    }
                    for (int b = 0; b < barrelPos.Count; b++)
                    {
                        barrelPos[b] -= new Vector3(0.2f, 0, 0);
                    }
                }
                
                //Cull Barrels
                barrelPos.RemoveAll(a => a.X < playerPos.X - 30);

                //Collision Detection
                for (int b = 0; b < barrelPos.Count; b++)
                {
                    if (Math.Abs(playerPos.X - barrelPos[b].X) < TARGET_RADIUS && Math.Abs(playerPos.Z - barrelPos[b].Z) < TARGET_RADIUS && Math.Abs(playerPos.Y - barrelPos[b].Y) < TARGET_RADIUS)
                    {
                        gameOver = true;
                        break;
                    }
                }

                //Strafing Right and Left, speed changes along with difficulty
                if (kState.IsKeyDown(Keys.Right))
                {
                    if (difficultyTimer <= 0)
                    {
                        playerPos += new Vector3(0, 0, .45f);
                    }
                    else
                    {
                        playerPos += new Vector3(0, 0, .3f);
                    }
                }
                if (kState.IsKeyDown(Keys.Left))
                {
                    if (difficultyTimer <= 0)
                    {
                        playerPos += new Vector3(0, 0, -.45f);
                    }
                    else
                    {
                        playerPos += new Vector3(0, 0, -.3f);
                    }
                }

                //Jumping, height changes along with difficulty
                if (kState.IsKeyDown(Keys.Space))
                {
                    if(difficultyTimer <= 0)
                    {
                        playerPos += new Vector3(0, .7f, 0);
                    } 
                    else
                    {
                        playerPos += new Vector3(0, .4f, 0);
                    }
                }
                if (kState.IsKeyUp(Keys.Space) && playerPos.Y >= -5)
                {
                    if(difficultyTimer <= 0)
                    {
                        playerPos += new Vector3(0, -0.25f, 0);
                    }
                    else
                    {
                        playerPos += new Vector3(0, -0.15f, 0);
                    }
                    
                }

                //Optional Camera Controls
                if (kState.IsKeyDown(Keys.D))
                {
                    cameraPos += new Vector3(0.3f, 0, 0);
                }
                if (kState.IsKeyDown(Keys.A))
                {
                    cameraPos += new Vector3(-0.3f, 0, 0);
                }
                if (kState.IsKeyDown(Keys.W))
                {
                    cameraPos += new Vector3(0, 0.3f, 0);
                }
                if (kState.IsKeyDown(Keys.S))
                {
                    cameraPos += new Vector3(0, -0.3f, 0);
                }

                //Update Timers
                timer += (float)gameTime.ElapsedGameTime.TotalSeconds;
                difficultyTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            //Begin drawing UI elements
            _spriteBatch.Begin();

            //Draw Background
            _spriteBatch.Draw(background, new Vector2(0, 0), Color.White);

            //UI Element Controls
            if (!gameStart && !gameOver)
            {
                //if game has not started yet
                _spriteBatch.DrawString(largeGameFont, "Welcome to Festival Charles!", startPosition, Color.Yellow);
                _spriteBatch.DrawString(gameFont, "Click Space to Jump", new Vector2(750, 800), Color.Yellow);
                _spriteBatch.DrawString(gameFont, "Use the Left and Right arrow keys to strafe", new Vector2(750, 820), Color.Yellow);
                _spriteBatch.DrawString(gameFont, "Use WASD to control the camera", new Vector2(750, 840), Color.Yellow);
                _spriteBatch.DrawString(largeGameFont, "Click to Start Game", new Vector2(750, 880), Color.Yellow);
            }
            if (gameStart && !gameOver)
            {
                //while game is running
                _spriteBatch.DrawString(largeGameFont, "Time Elapsed: " + Math.Round((Decimal)timer, 1), new Vector2(850, 750), Color.Yellow);
            }
            if (difficultyTimer <= 5f && difficultyTimer >= 0f && !gameOver)
            {
                //ten second mark
                _spriteBatch.DrawString(largeGameFont, "The difficulty is about to increase!", new Vector2(850, 650), Color.Yellow);
            }
            if (difficultyTimer <= 0f && difficultyTimer >= -5.0f && !gameOver)
            {
                //15 second mark
                _spriteBatch.DrawString(largeGameFont, "Difficulty increased!", new Vector2(850, 650), Color.Yellow);
            }
            if (gameOver)
            {
                //game has ended
                _spriteBatch.DrawString(largeGameFont, "Game over! You suvived " + Math.Round((Decimal)timer, 1) + " seconds!", new Vector2(750, 750), Color.Yellow);
                _spriteBatch.DrawString(gameFont, "Created by Corbin Kiefner", new Vector2(750, 780), Color.Yellow);
            }

            _spriteBatch.End();

            //Begin drawing world and models
            Matrix proj = Matrix.CreatePerspectiveFieldOfView(MathHelper.ToRadians(60), 1, 0.001f, 1000f);
            Matrix view = Matrix.CreateLookAt(cameraPos, new Vector3(playerPos.X, 0, 0), new Vector3(0, 1, 0));
            Matrix world = Matrix.CreateScale(0.005f) * Matrix.CreateRotationY(MathHelper.ToRadians(90)) * Matrix.CreateTranslation(playerPos);

            //Draw Game Assets
            player.Draw(world, view, proj);
            foreach (Vector3 pos in barrelPos)
            {
                world = Matrix.CreateScale(0.1f)
                    * Matrix.CreateTranslation(pos);
                barrel.Draw(world, view, proj);
            }

            base.Draw(gameTime);
        }
    }
}
